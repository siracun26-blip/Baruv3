# SubPlayer Offline & Online (Android)

Pemutar video Android dengan terjemahan subtitle `.srt` otomatis **Offline** (ML Kit Translation), **Online** (Cloud / Gemini API), dan **Manajer Paket Unduhan Bahasa** menggunakan **Media3 ExoPlayer** dan **Jetpack Compose (Material 3)**.

## Fitur Utama
- **Manajer Paket Bahasa Offline & Link Download:**
  - Unduh atau hapus paket model bahasa ML Kit langsung dari aplikasi (`RemoteModelManager`).
  - Dilengkapi **link arsip model langsung** (`https://dl.google.com/dl/android/mlkit/translate/v25/...`) dan tautan katalog resmi Google ML Kit untuk setiap bahasa, lengkap dengan tombol salin URL dan buka di browser.
- **3 Mode Terjemahan (`TranslationMode`):**
  - **Hybrid (Online → Offline):** Mengutamakan terjemahan online dan otomatis beralih ke mesin offline ML Kit jika koneksi terputus.
  - **Online (Cloud):** Menerjemahkan langsung lewat layanan cloud (atau **Gemini API** jika API Key diisi di pengaturan).
  - **Offline (ML Kit):** 100% lokal di perangkat setelah paket bahasa terunduh.
- **Semua Bahasa + Pencarian & Swap**, **Simpan & Muat Ulang `.srt`**, serta **Kontrol Gesture** (*seek*, kecerahan, volume).

## Daftar Link Download Paket Bahasa ML Kit (Base URL)
- Katalog Resmi Model Terjemahan ML Kit: `https://developers.google.com/ml-kit/language/translation/translation-models`
- Format Arsip Paket Bahasa (per kode ISO-639): `https://dl.google.com/dl/android/mlkit/translate/v25/en_<kode_bahasa>.zip` (contoh Indonesia: `https://dl.google.com/dl/android/mlkit/translate/v25/en_id.zip`, Jepang: `https://dl.google.com/dl/android/mlkit/translate/v25/en_ja.zip`, Korea: `https://dl.google.com/dl/android/mlkit/translate/v25/en_ko.zip`).
