package com.example.offlinesubplayer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.mlkit.nl.translate.TranslateLanguage
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale

data class PlayerUiState(
    val videoUri: Uri? = null,
    val subtitleName: String? = null,
    val cues: List<SubtitleCue> = emptyList(),
    val activeCue: SubtitleCue? = null,
    val isPlaying: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val showControls: Boolean = true,
    val translateEnabled: Boolean = true,
    val translationMode: TranslationMode = TranslationMode.HYBRID,
    val geminiApiKey: String = "",
    val isOfflineModelReady: Boolean = false,
    val downloadedLanguages: Set<String> = emptySet(),
    val downloadingLanguages: Set<String> = emptySet(),
    val sourceLang: String = TranslateLanguage.ENGLISH,
    val targetLang: String = TranslateLanguage.INDONESIAN,
    val translationProgress: Float? = null,
    val statusMessage: String = "Pilih video dan file .srt untuk mulai"
)

class VideoPlayerViewModel : ViewModel() {
    private val offlineTranslator = OfflineTranslatorManager()
    private val onlineTranslator = OnlineTranslatorManager()
    private var translationJob: Job? = null

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    init {
        refreshDownloadedLanguages()
        prepareOfflineModel()
    }

    fun refreshDownloadedLanguages() {
        viewModelScope.launch {
            runCatching {
                offlineTranslator.getDownloadedLanguageCodes()
            }.onSuccess { codes ->
                _uiState.update { it.copy(downloadedLanguages = codes) }
            }
        }
    }

    fun downloadLanguagePack(languageCode: String) {
        if (_uiState.value.downloadingLanguages.contains(languageCode)) return
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    downloadingLanguages = it.downloadingLanguages + languageCode,
                    statusMessage = "Mengunduh paket bahasa ${LanguageCatalog.findLabel(languageCode)} (~30 MB)..."
                )
            }
            runCatching {
                offlineTranslator.downloadLanguagePack(languageCode)
            }.onSuccess {
                refreshDownloadedLanguages()
                _uiState.update {
                    it.copy(
                        downloadingLanguages = it.downloadingLanguages - languageCode,
                        statusMessage = "Paket ${LanguageCatalog.findLabel(languageCode)} terunduh"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        downloadingLanguages = it.downloadingLanguages - languageCode,
                        statusMessage = "Gagal unduh ${languageCode.uppercase()}: ${err.localizedMessage ?: "cek koneksi"}"
                    )
                }
            }
        }
    }

    fun deleteLanguagePack(languageCode: String) {
        viewModelScope.launch {
            runCatching {
                offlineTranslator.deleteLanguagePack(languageCode)
            }.onSuccess {
                refreshDownloadedLanguages()
                _uiState.update {
                    it.copy(statusMessage = "Paket bahasa ${languageCode.uppercase()} dihapus dari perangkat")
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(statusMessage = "Gagal menghapus paket: ${err.localizedMessage ?: "error"}")
                }
            }
        }
    }

    fun prepareOfflineModel(
        sourceLang: String = _uiState.value.sourceLang,
        targetLang: String = _uiState.value.targetLang
    ) {
        viewModelScope.launch {
            if (_uiState.value.translationMode == TranslationMode.ONLINE) {
                _uiState.update {
                    it.copy(
                        statusMessage = "Mode Online siap (${sourceLang.uppercase()} → ${targetLang.uppercase()})"
                    )
                }
                if (_uiState.value.translateEnabled && _uiState.value.cues.isNotEmpty()) {
                    translateAllCues()
                }
                return@launch
            }

            _uiState.update { it.copy(statusMessage = "Menyiapkan paket terjemahan offline...") }
            runCatching {
                offlineTranslator.prepareModel(sourceLang, targetLang)
            }.onSuccess {
                refreshDownloadedLanguages()
                _uiState.update {
                    it.copy(
                        isOfflineModelReady = true,
                        statusMessage = "${it.translationMode.label} siap (${sourceLang.uppercase()} → ${targetLang.uppercase()})"
                    )
                }
                if (_uiState.value.translateEnabled && _uiState.value.cues.isNotEmpty()) {
                    translateAllCues()
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isOfflineModelReady = false,
                        statusMessage = if (it.translationMode == TranslationMode.HYBRID) {
                            "Offline belum siap, memakai Online (${err.localizedMessage ?: "offline gagal"})"
                        } else {
                            "Gagal menyiapkan bahasa offline: ${err.localizedMessage ?: "cek koneksi saat unduh model"}"
                        }
                    )
                }
                if (_uiState.value.translationMode == TranslationMode.HYBRID &&
                    _uiState.value.translateEnabled &&
                    _uiState.value.cues.isNotEmpty()
                ) {
                    translateAllCues()
                }
            }
        }
    }

    fun setTranslationMode(mode: TranslationMode) {
        if (mode == _uiState.value.translationMode) return
        translationJob?.cancel()
        val clearedCues = _uiState.value.cues.map { it.copy(translatedText = null) }
        _uiState.update {
            it.copy(
                translationMode = mode,
                cues = clearedCues,
                activeCue = null,
                translationProgress = null
            )
        }
        if (mode == TranslationMode.ONLINE) {
            _uiState.update {
                it.copy(statusMessage = "Mode Online aktif (${it.sourceLang.uppercase()} → ${it.targetLang.uppercase()})")
            }
            if (_uiState.value.translateEnabled && _uiState.value.cues.isNotEmpty()) {
                translateAllCues()
            }
        } else {
            prepareOfflineModel(_uiState.value.sourceLang, _uiState.value.targetLang)
        }
    }

    fun updateGeminiApiKey(newKey: String) {
        onlineTranslator.clearCache()
        val clearedCues = _uiState.value.cues.map { it.copy(translatedText = null) }
        _uiState.update {
            it.copy(
                geminiApiKey = newKey.trim(),
                cues = clearedCues,
                statusMessage = if (newKey.isNotBlank()) "API Key Gemini tersimpan untuk terjemahan online" else "Menggunakan layanan terjemahan online standar"
            )
        }
        if (_uiState.value.translateEnabled &&
            _uiState.value.cues.isNotEmpty() &&
            _uiState.value.translationMode != TranslationMode.OFFLINE
        ) {
            translateAllCues()
        }
    }

    fun changeLanguagePair(newSourceLang: String, newTargetLang: String) {
        if (newSourceLang == _uiState.value.sourceLang && newTargetLang == _uiState.value.targetLang) return
        translationJob?.cancel()

        val clearedCues = _uiState.value.cues.map { it.copy(translatedText = null) }
        _uiState.update {
            it.copy(
                sourceLang = newSourceLang,
                targetLang = newTargetLang,
                cues = clearedCues,
                activeCue = null,
                isOfflineModelReady = false,
                translationProgress = null
            )
        }
        prepareOfflineModel(newSourceLang, newTargetLang)
    }

    fun swapLanguages() {
        val currentSource = _uiState.value.sourceLang
        val currentTarget = _uiState.value.targetLang
        if (currentSource == currentTarget) return
        changeLanguagePair(newSourceLang = currentTarget, newTargetLang = currentSource)
    }

    fun setVideoUri(uri: Uri) {
        _uiState.update { it.copy(videoUri = uri) }
    }

    fun loadSubtitles(fileName: String?, srtContent: String) {
        val parsed = SrtParser.parse(srtContent)
        _uiState.update {
            it.copy(
                subtitleName = fileName ?: "Subtitle.srt",
                cues = parsed,
                activeCue = null,
                statusMessage = "Memuat ${parsed.size} baris subtitle"
            )
        }
        if (_uiState.value.translateEnabled) {
            translateAllCues()
        }
    }

    fun toggleAutoTranslate(enabled: Boolean) {
        _uiState.update { it.copy(translateEnabled = enabled) }
        if (enabled) {
            translateAllCues()
        }
    }

    fun exportTranslatedSrt(context: Context, uri: Uri, fileName: String? = null) {
        viewModelScope.launch {
            val cues = _uiState.value.cues
            if (cues.isEmpty()) {
                _uiState.update { it.copy(statusMessage = "Belum ada subtitle untuk disimpan") }
                return@launch
            }
            val srtText = SrtExporter.buildSrtContent(cues, preferTranslated = true)
            SrtExporter.writeToUri(context, uri, srtText)
                .onSuccess {
                    val savedContent = context.contentResolver
                        .openInputStream(uri)
                        ?.bufferedReader()
                        ?.use { it.readText() }
                        ?: srtText
                    loadSubtitles(
                        fileName = fileName ?: uri.lastPathSegment ?: "terjemahan.srt",
                        srtContent = savedContent
                    )
                    _uiState.update {
                        it.copy(statusMessage = "File .srt disimpan & dimuat ulang")
                    }
                }
                .onFailure { err ->
                    _uiState.update {
                        it.copy(statusMessage = "Gagal menyimpan .srt: ${err.localizedMessage ?: "error"}")
                    }
                }
        }
    }

    private suspend fun translateSingleCue(text: String): String {
        val snapshot = _uiState.value
        return when (snapshot.translationMode) {
            TranslationMode.OFFLINE -> {
                if (snapshot.isOfflineModelReady) offlineTranslator.translateText(text) else text
            }
            TranslationMode.ONLINE -> {
                onlineTranslator.translateText(
                    text = text,
                    sourceLang = snapshot.sourceLang,
                    targetLang = snapshot.targetLang,
                    geminiApiKey = snapshot.geminiApiKey
                ).getOrElse { text }
            }
            TranslationMode.HYBRID -> {
                val onlineRes = onlineTranslator.translateText(
                    text = text,
                    sourceLang = snapshot.sourceLang,
                    targetLang = snapshot.targetLang,
                    geminiApiKey = snapshot.geminiApiKey
                )
                onlineRes.getOrElse {
                    if (snapshot.isOfflineModelReady) offlineTranslator.translateText(text) else text
                }
            }
        }
    }

    private fun translateAllCues() {
        translationJob?.cancel()
        translationJob = viewModelScope.launch {
            val snapshot = _uiState.value
            if (snapshot.translationMode == TranslationMode.OFFLINE && !snapshot.isOfflineModelReady) {
                return@launch
            }

            val currentList = snapshot.cues.toMutableList()
            if (currentList.isEmpty()) {
                _uiState.update { it.copy(translationProgress = null) }
                return@launch
            }

            _uiState.update { it.copy(translationProgress = 0f) }

            for (i in currentList.indices) {
                val cue = currentList[i]
                val updatedCue = if (cue.translatedText == null) {
                    cue.copy(translatedText = translateSingleCue(cue.originalText))
                } else {
                    cue
                }
                currentList[i] = updatedCue

                val progress = (i + 1).toFloat() / currentList.size.toFloat()
                if (i % 3 == 0 || i == currentList.lastIndex) {
                    _uiState.update {
                        it.copy(
                            cues = currentList.toList(),
                            translationProgress = progress,
                            statusMessage = "Menerjemahkan (${it.translationMode.label})... ${(progress * 100).toInt()}%"
                        )
                    }
                }
            }

            _uiState.update {
                it.copy(
                    translationProgress = null,
                    statusMessage = "Terjemahan selesai [${it.translationMode.label}] (${it.sourceLang.uppercase()} → ${it.targetLang.uppercase()})"
                )
            }
        }
    }

    fun onPlaybackTick(positionMs: Long, durationMs: Long, isPlaying: Boolean) {
        val cue = _uiState.value.cues.firstOrNull { positionMs in it.startMs..it.endMs }
        _uiState.update {
            it.copy(
                currentPositionMs = positionMs,
                durationMs = durationMs.coerceAtLeast(0L),
                isPlaying = isPlaying,
                activeCue = cue
            )
        }
    }

    fun toggleControls() {
        _uiState.update { it.copy(showControls = !it.showControls) }
    }

    override fun onCleared() {
        translationJob?.cancel()
        offlineTranslator.release()
        super.onCleared()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF7DD3FC),
                    surface = Color(0xFF090D16),
                    background = Color(0xFF090D16)
                )
            ) {
                OfflineSubtitlePlayerScreen()
            }
        }
    }
}

@Composable
fun LanguagePackManagerDialog(
    downloadedCodes: Set<String>,
    downloadingCodes: Set<String>,
    onDismiss: () -> Unit,
    onDownloadPack: (String) -> Unit,
    onDeletePack: (String) -> Unit
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var query by remember { mutableStateOf("") }
    var filterDownloadedOnly by remember { mutableStateOf(false) }

    val filtered = remember(query, downloadedCodes, filterDownloadedOnly) {
        LanguageCatalog.allLanguages.filter { item ->
            val matchesQuery = query.isBlank() ||
                item.label.contains(query, ignoreCase = true) ||
                item.code.contains(query, ignoreCase = true)
            val matchesDownloaded = !filterDownloadedOnly || downloadedCodes.contains(item.code)
            matchesQuery && matchesDownloaded
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Paket Bahasa Offline & Link Download", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    text = "Terunduh: ${downloadedCodes.size} dari ${LanguageCatalog.allLanguages.size} bahasa (~30 MB/paket)",
                    fontSize = 12.sp,
                    color = Color(0xFF7DD3FC)
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Cari bahasa atau kode...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = filterDownloadedOnly,
                        onClick = { filterDownloadedOnly = !filterDownloadedOnly },
                        label = { Text("Sudah Diunduh (${downloadedCodes.size})", fontSize = 11.sp) }
                    )
                    TextButton(
                        onClick = {
                            runCatching {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse(LanguageCatalog.MLKIT_MODELS_GUIDE_URL))
                                )
                            }
                        }
                    ) {
                        Icon(Icons.Rounded.OpenInBrowser, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Katalog Resmi", fontSize = 11.sp)
                    }
                }
                Spacer(Modifier.height(6.dp))
                LazyColumn(
                    modifier = Modifier.heightIn(max = 340.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filtered.size) { idx ->
                        val item = filtered[idx]
                        val isDownloaded = downloadedCodes.contains(item.code)
                        val isDownloading = downloadingCodes.contains(item.code)

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.White.copy(alpha = 0.06f))
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.label,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = item.packageArchiveUrl,
                                        fontSize = 10.sp,
                                        color = Color(0xFF7DD3FC),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = {
                                            clipboard.setText(AnnotatedString(item.packageArchiveUrl))
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.ContentCopy,
                                            contentDescription = "Salin Link Paket",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            runCatching {
                                                context.startActivity(
                                                    Intent(Intent.ACTION_VIEW, Uri.parse(item.packageArchiveUrl))
                                                )
                                            }
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Link,
                                            contentDescription = "Buka Link Download",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    if (isDownloading) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(22.dp),
                                            strokeWidth = 2.dp
                                        )
                                    } else if (isDownloaded) {
                                        IconButton(
                                            onClick = { onDeletePack(item.code) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.DeleteOutline,
                                                contentDescription = "Hapus Paket Offline",
                                                tint = Color(0xFFFCA5A5),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    } else {
                                        IconButton(
                                            onClick = { onDownloadPack(item.code) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Download,
                                                contentDescription = "Unduh ke Perangkat",
                                                tint = Color(0xFF7DD3FC),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Tutup") }
        }
    )
}

@Composable
fun TranslationSettingsDialog(
    currentMode: TranslationMode,
    currentApiKey: String,
    downloadedCount: Int,
    onDismiss: () -> Unit,
    onSelectMode: (TranslationMode) -> Unit,
    onSaveApiKey: (String) -> Unit,
    onOpenPackManager: () -> Unit
) {
    var apiKeyInput by remember { mutableStateOf(currentApiKey) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Pengaturan Terjemahan", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Pilih Mesin Terjemahan:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                TranslationMode.entries.forEach { mode ->
                    val selected = mode == currentMode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                else Color.White.copy(alpha = 0.05f)
                            )
                            .clickable { onSelectMode(mode) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(mode.label, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                            val desc = when (mode) {
                                TranslationMode.OFFLINE -> "100% lokal memakai paket bahasa ML Kit"
                                TranslationMode.ONLINE -> "Terjemahan cloud langsung tanpa unduh paket"
                                TranslationMode.HYBRID -> "Prioritas Online, otomatis fallback ke Offline jika internet putus"
                            }
                            Text(desc, fontSize = 11.sp, color = Color.White.copy(alpha = 0.7f))
                        }
                        if (selected) {
                            Icon(Icons.Rounded.Check, contentDescription = null)
                        }
                    }
                }

                FilledTonalButton(
                    onClick = {
                        onDismiss()
                        onOpenPackManager()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.DownloadForOffline, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Kelola Paket Bahasa & Link Download ($downloadedCount)")
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

                Text(
                    text = "Gemini API Key (Opsional untuk Online):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                OutlinedTextField(
                    value = apiKeyInput,
                    onValueChange = { apiKeyInput = it },
                    placeholder = { Text("AIza... (kosongkan untuk server standar)") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSaveApiKey(apiKeyInput)
                onDismiss()
            }) {
                Text("Simpan")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@Composable
fun LanguagePickerDialog(
    title: String,
    selectedCode: String,
    downloadedCodes: Set<String>,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query) {
        if (query.isBlank()) LanguageCatalog.allLanguages
        else LanguageCatalog.allLanguages.filter {
            it.label.contains(query, ignoreCase = true) || it.code.contains(query, ignoreCase = true)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Cari bahasa atau kode...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                LazyColumn(
                    modifier = Modifier.heightIn(max = 320.dp)
                ) {
                    items(filtered.size) { idx ->
                        val item = filtered[idx]
                        val isSelected = item.code == selectedCode
                        val isOfflineReady = downloadedCodes.contains(item.code)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                    else Color.Transparent
                                )
                                .clickable {
                                    onSelect(item.code)
                                    onDismiss()
                                }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.label,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                                if (isOfflineReady) {
                                    Text(
                                        text = "Paket offline terunduh",
                                        fontSize = 11.sp,
                                        color = Color(0xFF7DD3FC)
                                    )
                                }
                            }
                            if (isSelected) {
                                Icon(Icons.Rounded.Check, contentDescription = null)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Tutup") }
        }
    )
}

@Composable
fun OfflineSubtitlePlayerScreen(vm: VideoPlayerViewModel = viewModel()) {
    val context = LocalContext.current
    val activity = context as? Activity
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val state by vm.uiState.collectAsState()

    var pickingSource by remember { mutableStateOf(false) }
    var pickingTarget by remember { mutableStateOf(false) }
    var showingModeSettings by remember { mutableStateOf(false) }
    var showingPackManager by remember { mutableStateOf(false) }
    var suggestedExportName by remember { mutableStateOf("subtitle_id.srt") }

    var seekPreviewMs by remember { mutableStateOf<Long?>(null) }
    var brightnessLevel by remember { mutableFloatStateOf(0.7f) }
    var volumePercent by remember { mutableIntStateOf(50) }
    var activeGestureLabel by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(activity) {
        val currentWinBrightness = activity?.window?.attributes?.screenBrightness ?: -1f
        if (currentWinBrightness >= 0f) {
            brightnessLevel = currentWinBrightness.coerceIn(0.08f, 1.0f)
        } else {
            val sysBrightness = runCatching {
                Settings.System.getInt(
                    context.contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS
                )
            }.getOrDefault(180)
            brightnessLevel = (sysBrightness / 255f).coerceIn(0.08f, 1.0f)
        }
    }

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = true
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose { exoPlayer.release() }
    }

    LaunchedEffect(state.videoUri) {
        state.videoUri?.let { uri ->
            exoPlayer.setMediaItem(MediaItem.fromUri(uri))
            exoPlayer.prepare()
            exoPlayer.play()
        }
    }

    LaunchedEffect(exoPlayer) {
        while (true) {
            vm.onPlaybackTick(
                positionMs = exoPlayer.currentPosition,
                durationMs = exoPlayer.duration,
                isPlaying = exoPlayer.isPlaying
            )
            delay(150L)
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { vm.setVideoUri(it) }
    }

    val subtitlePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            val content = context.contentResolver.openInputStream(it)?.bufferedReader()?.use { r -> r.readText() }
            if (!content.isNullOrBlank()) {
                vm.loadSubtitles(it.lastPathSegment, content)
            }
        }
    }

    val saveSubtitleLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/x-subrip")
    ) { uri ->
        uri?.let { vm.exportTranslatedSrt(context, it, suggestedExportName) }
    }

    if (pickingSource) {
        LanguagePickerDialog(
            title = "Pilih Bahasa Asal",
            selectedCode = state.sourceLang,
            downloadedCodes = state.downloadedLanguages,
            onDismiss = { pickingSource = false },
            onSelect = { code -> vm.changeLanguagePair(code, state.targetLang) }
        )
    }

    if (pickingTarget) {
        LanguagePickerDialog(
            title = "Pilih Bahasa Tujuan",
            selectedCode = state.targetLang,
            downloadedCodes = state.downloadedLanguages,
            onDismiss = { pickingTarget = false },
            onSelect = { code -> vm.changeLanguagePair(state.sourceLang, code) }
        )
    }

    if (showingModeSettings) {
        TranslationSettingsDialog(
            currentMode = state.translationMode,
            currentApiKey = state.geminiApiKey,
            downloadedCount = state.downloadedLanguages.size,
            onDismiss = { showingModeSettings = false },
            onSelectMode = { mode -> vm.setTranslationMode(mode) },
            onSaveApiKey = { key -> vm.updateGeminiApiKey(key) },
            onOpenPackManager = {
                vm.refreshDownloadedLanguages()
                showingPackManager = true
            }
        )
    }

    if (showingPackManager) {
        LanguagePackManagerDialog(
            downloadedCodes = state.downloadedLanguages,
            downloadingCodes = state.downloadingLanguages,
            onDismiss = { showingPackManager = false },
            onDownloadPack = { code -> vm.downloadLanguagePack(code) },
            onDeletePack = { code -> vm.deleteLanguagePack(code) }
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090D16))
            .clickable { vm.toggleControls() }
            .pointerInput(state.durationMs) {
                var accumulatedSeekDeltaMs = 0L
                detectHorizontalDragGestures(
                    onDragStart = {
                        accumulatedSeekDeltaMs = 0L
                        seekPreviewMs = exoPlayer.currentPosition
                    },
                    onHorizontalDrag = { change, dragAmount ->
                        change.consume()
                        if (state.durationMs > 0L) {
                            accumulatedSeekDeltaMs += (dragAmount * 100f).toLong()
                            val target = (exoPlayer.currentPosition + accumulatedSeekDeltaMs)
                                .coerceIn(0L, state.durationMs)
                            seekPreviewMs = target
                        }
                    },
                    onDragEnd = {
                        seekPreviewMs?.let { target -> exoPlayer.seekTo(target) }
                        seekPreviewMs = null
                    },
                    onDragCancel = {
                        seekPreviewMs = null
                    }
                )
            }
    ) {
        Row(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onVerticalDrag = { change, dragAmount ->
                                change.consume()
                                val delta = -dragAmount / 600f
                                val next = (brightnessLevel + delta).coerceIn(0.08f, 1.0f)
                                brightnessLevel = next
                                activity?.window?.let { win ->
                                    val params = win.attributes
                                    params.screenBrightness = next
                                    win.attributes = params
                                }
                                activeGestureLabel = "Kecerahan ${(next * 100).toInt()}%"
                            },
                            onDragEnd = { activeGestureLabel = null },
                            onDragCancel = { activeGestureLabel = null }
                        )
                    }
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onVerticalDrag = { change, dragAmount ->
                                change.consume()
                                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                val stepDelta = (-dragAmount / 90f).toInt()
                                if (stepDelta != 0) {
                                    val nextVol = (curVol + stepDelta).coerceIn(0, maxVol)
                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, nextVol, 0)
                                    volumePercent = ((nextVol.toFloat() / maxVol.toFloat()) * 100f).toInt()
                                } else {
                                    volumePercent = ((curVol.toFloat() / maxVol.toFloat()) * 100f).toInt()
                                }
                                activeGestureLabel = "Volume $volumePercent%"
                            },
                            onDragEnd = { activeGestureLabel = null },
                            onDragCancel = { activeGestureLabel = null }
                        )
                    }
            )
        }

        if (state.videoUri != null) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = false
                    }
                },
                update = { it.player = exoPlayer },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Rounded.OndemandVideo,
                    contentDescription = null,
                    tint = Color(0xFF7DD3FC),
                    modifier = Modifier.size(64.dp)
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    text = "SubPlayer Offline & Online",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = state.statusMessage,
                    color = Color.White.copy(alpha = 0.72f),
                    textAlign = TextAlign.Center
                )
            }
        }

        val badgeText = seekPreviewMs?.let { "Seek → ${formatTime(it)}" } ?: activeGestureLabel
        if (badgeText != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.Black.copy(alpha = 0.8f))
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) {
                Text(
                    text = badgeText,
                    color = Color(0xFF7DD3FC),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        AnimatedVisibility(
            visible = state.showControls,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Black.copy(alpha = 0.82f), Color.Transparent)
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "SubPlayer • ${state.translationMode.label}",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = state.statusMessage,
                            color = Color(0xFF7DD3FC),
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                vm.refreshDownloadedLanguages()
                                showingPackManager = true
                            },
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.14f))
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.DownloadForOffline,
                                contentDescription = "Paket Unduhan Bahasa",
                                tint = Color(0xFF7DD3FC),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(Modifier.width(6.dp))
                        IconButton(
                            onClick = { showingModeSettings = true },
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.14f))
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CloudSync,
                                contentDescription = "Mode Online/Offline",
                                tint = Color(0xFF7DD3FC),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Text("Auto", color = Color.White, fontSize = 12.sp)
                        Spacer(Modifier.width(4.dp))
                        Switch(
                            checked = state.translateEnabled,
                            onCheckedChange = { vm.toggleAutoTranslate(it) }
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { pickingSource = true },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = LanguageCatalog.findLabel(state.sourceLang),
                            color = Color.White,
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }

                    IconButton(
                        onClick = { vm.swapLanguages() },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.14f))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SwapHoriz,
                            contentDescription = "Tukar Bahasa",
                            tint = Color(0xFF7DD3FC)
                        )
                    }

                    OutlinedButton(
                        onClick = { pickingTarget = true },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = LanguageCatalog.findLabel(state.targetLang),
                            color = Color.White,
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }
                }

                state.translationProgress?.let { progress ->
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { progress.coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(99.dp)),
                        color = Color(0xFF7DD3FC),
                        trackColor = Color.White.copy(alpha = 0.2f)
                    )
                }
            }
        }

        state.activeCue?.let { cue ->
            val displayText = if (state.translateEnabled && !cue.translatedText.isNullOrBlank()) {
                cue.translatedText
            } else {
                cue.originalText
            }
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(
                        bottom = if (state.showControls) 124.dp else 36.dp,
                        start = 24.dp,
                        end = 24.dp
                    )
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.Black.copy(alpha = 0.72f))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(
                    text = displayText,
                    color = Color.White,
                    fontSize = 16.sp,
                    lineHeight = 22.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            }
        }

        AnimatedVisibility(
            visible = state.showControls,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                if (state.durationMs > 0L) {
                    Slider(
                        value = (state.currentPositionMs.toFloat() / state.durationMs.toFloat()).coerceIn(0f, 1f),
                        onValueChange = { frac ->
                            exoPlayer.seekTo((frac * state.durationMs).toLong())
                        }
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(formatTime(state.currentPositionMs), color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        Text(formatTime(state.durationMs), color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    }
                }

                Spacer(Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledTonalButton(onClick = { videoPicker.launch(arrayOf("video/*")) }) {
                        Icon(Icons.Rounded.VideoFile, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Video", fontSize = 12.sp)
                    }

                    FilledTonalButton(onClick = { subtitlePicker.launch(arrayOf("*/*")) }) {
                        Icon(Icons.Rounded.Subtitles, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("SRT", fontSize = 12.sp)
                    }

                    IconButton(
                        onClick = {
                            if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                        },
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF7DD3FC))
                    ) {
                        Icon(
                            imageVector = if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = Color(0xFF090D16),
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    FilledTonalButton(
                        enabled = state.cues.isNotEmpty(),
                        onClick = {
                            val baseName = (state.subtitleName ?: "subtitle")
                                .substringBeforeLast(".")
                            val fileName = "${baseName}_${state.targetLang}.srt"
                            suggestedExportName = fileName
                            saveSubtitleLauncher.launch(fileName)
                        }
                    ) {
                        Icon(Icons.Rounded.SaveAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Simpan", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val min = totalSec / 60L
    val sec = totalSec % 60L
    return String.format(Locale.US, "%02d:%02d", min, sec)
}
